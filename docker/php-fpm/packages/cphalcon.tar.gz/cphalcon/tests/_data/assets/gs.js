var gs;
