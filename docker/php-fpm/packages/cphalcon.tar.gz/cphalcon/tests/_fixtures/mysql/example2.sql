CREATE TABLE `table` (
	`column2` INT(18) UNSIGNED,
	`column3` DECIMAL(10,2) NOT NULL,
	`column1` VARCHAR(10),
	PRIMARY KEY (`column3`)
)
