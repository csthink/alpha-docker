<?php

class ControllerBase extends \Phalcon\Mvc\Controller
{

	public function serviceAction()
	{
		return "hello";
	}

}
