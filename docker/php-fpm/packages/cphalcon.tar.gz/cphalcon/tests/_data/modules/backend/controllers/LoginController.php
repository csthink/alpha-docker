<?php

namespace Phalcon\Test\Modules\Backend\Controllers;

use Phalcon\Mvc\Controller;

class LoginController extends Controller
{
    public function indexAction()
    {
    }
}
