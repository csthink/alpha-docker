$(document).ready(function () {
    $("#registration").validate({
        //
    });
});
