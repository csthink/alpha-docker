<?php

namespace MyNamespace\Controllers;

class NamespacedAnnotationController
{
    /**
     * @Get("/")
     */
    public function indexAction()
    {
    }
}
