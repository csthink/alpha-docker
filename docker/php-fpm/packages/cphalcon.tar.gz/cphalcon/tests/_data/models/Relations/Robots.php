<?php

namespace Phalcon\Test\Models\Relations;

use Phalcon\Mvc\Model;

class Robots extends Model
{
}
