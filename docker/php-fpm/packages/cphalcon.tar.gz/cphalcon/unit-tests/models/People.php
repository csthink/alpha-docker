<?php

class People extends Phalcon\Mvc\Model
{

	public function getSource()
	{
		return 'personas';
	}

}
