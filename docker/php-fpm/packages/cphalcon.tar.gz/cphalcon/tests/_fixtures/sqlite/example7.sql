CREATE TABLE "table" (
	`column18` TINYINT
)
