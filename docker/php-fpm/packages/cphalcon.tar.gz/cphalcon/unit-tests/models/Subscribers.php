<?php

class Subscribers extends Phalcon\Mvc\Model
{

	public function getSource()
	{
		return 'subscriptores';
	}

}
