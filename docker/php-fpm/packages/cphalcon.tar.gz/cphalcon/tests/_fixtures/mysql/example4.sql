CREATE TABLE `table` (
	`column9` VARCHAR(10) DEFAULT "column9",
	`column10` INT(18) UNSIGNED DEFAULT "10"
)
