CREATE TABLE "table" (
	"column1" CHARACTER VARYING(10),
	"column2" INT
);
