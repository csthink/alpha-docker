<?php

namespace Phalcon\Test\Debug;

class ClassProperties
{
    public    $foo  = 1;
    protected $bar  = 2;
    private   $baz  = 3;
}
