CREATE TABLE `table` (
	`column1` VARCHAR(10),
	`column2` INT(18) UNSIGNED
)
