<?php

class Test1Controller extends \Phalcon\Mvc\Controller
{
}
